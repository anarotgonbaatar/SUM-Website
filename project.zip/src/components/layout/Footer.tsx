export default function Footer() {
	return (
		<div>
			<span
				className="
					flex text-center justify-center
					bg-[black]
					py-[1rem]
					border-t-2 border-[var(--glass)]
				"
			>
				Developed by Anar Otgonbaatar
			</span>
		</div>
	)
}