import { useId, useState } from "react"

type PillarProps = {
  title: string
  description: string
  defaultOpen?: boolean
}

export function Pillar({ title, description, defaultOpen = false }: PillarProps) {
	const [open, setOpen] = useState(defaultOpen)
	const contentId = useId()

	return (
		<div className="col-span-1">
			<button
				type="button"
				onClick={() => setOpen((v) => !v)}
				aria-expanded={open ? "true" : "false"}
				aria-controls={contentId}
				className="
					btn
					flex items-center justify-between!
					w-full text-left
					cursor-pointer select-none
					bg-(--gold)! text-[white]!
				"
			>
				<span className="text-[1.5rem] font-[700] text-[var(--crimson-dark)]">
					{title}
				</span>

				<span
					className="
						text-[1.25rem] font-[800] text-[black]
						mt-[-4px]
						transition-transform duration-250
					"
					style={{ transform: open ? "rotate(45deg)" : "rotate(0deg)" }}
					aria-hidden="true"
				>
				+
				</span>
			</button>

			<div
				id={contentId}
				className={`
					overflow-hidden h-[0px]!
					transition-all duration-250 ease-in-out
					${open ? "h-min! opacity-100 mt-[0.75rem]" : "h-[0px] opacity-0 mt-0"}
				`}
			>
				<p className="text-left px-[1rem]">
					{description}
				</p>
			</div>

		</div>
	)
}
