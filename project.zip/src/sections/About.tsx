import Phoenix from "../assets/logos/phoenix-white.png"
import { Pillar } from "../components/Pillar"

export default function About() {
	
	const pillars = [
		{
			key: "A",
			title: "Achievement",
			description:
				"We acknowledge our progress toward our goals and measure our personal growth. We celebrate our large accomplishments, as well as our small milestones. We do this all while maintaining focus and optimism in the face of adversity.",
		},
		{
			key: "B",
			title: "Brotherhood",
			description:
				"We are a family that supports each other. We are competitive at heart, but we are cooperative and wish for the success of our fellow brothers and sisters. We prioritize helping our family professionally and personally, always aiming to give first before we receive.",
		},
		{
			key: "L",
			title: "Leadership",
			description:
				"We lead by example. We expect the best and keep each other accountable. We inspire others through our actions and optimism. We choose to lead, even without a title, to work toward infecting others with optimism in their ability to succeed.",
		},
		{
			key: "E",
			title: "Entrepreneurship",
			description:
				"We are self-starters who take initiative towards our goals. We take calculated risks and do not fear failure; yet we embrace it. Like a phoenix, we are reborn after every failure. Failure is an unavoidable learning step in our path to greatness. We seek to innovate and excel in life; most importantly, looking to be able to pass it forward.",
		},
	]
	
	return (
        <section id='about-section'>
            
            <div className="flex flex-col">
				<span className="section-title mb-[0.5rem]!">Facta Non Verba</span>
				<span>Deeds not Words</span>
				<span>SUM is an organization that spends less time talking and more on doing and achieving.</span>
			</div>
            <p className='glass-card'>
                Sigma Upsilon Mu (SUM) is a co-ed entrepreneurship business fraternity established in March 2014.
            </p>
            
            <div className='glass-card'>
                <span className='text-[2rem] text-[var(--crimson-dark)]'>What We Do</span>
                <ul className="ml-[1.5rem]">
                    <li>We empower students to become lifelong learners and future entrepreneurs, executives, and financially independent individuals.</li>
                    <li>We organize a variety of events each semester, such as:</li>
                    <li>8-hour business challenges</li>
                    <li>Networking events</li>
                    <li>Guest speaker sessions from industry professionals</li>
                    <li>Workshops and hands-on entrepreneurial projects</li>
                </ul>
            </div>

			<div
				className="
					!grid !grid-cols-1 md:!grid-cols-2 lg:!grid-cols-4
					gap-[1rem]
				"
			>
				{pillars.map((p) => (
					<Pillar
						key={p.key}
						title={p.title}
						description={p.description}
					/>
				))}
			</div>
            
        </section>
    )
}